"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useRouter } from "next/navigation";
import { useState } from "react";
import Link from "next/link";

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import type { Tournament } from "@/lib/types";
import { User, Users, Mail, Gamepad, MessageSquare, Instagram, Youtube } from "lucide-react";
import { handleSuccessfulBookingAction } from '@/lib/actions';

const bookingFormSchema = z.object({
  playerName: z.string().min(2, {
    message: "Player name must be at least 2 characters.",
  }),
  ign: z.string().min(2, {
    message: "In-Game Name (IGN) must be at least 2 characters.",
  }),
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
  teamName: z.string().min(2, { message: "Team Name is required." }),
  player2Name: z.string().min(2, { message: "Player 2 Name is required." }),
  player3Name: z.string().min(2, { message: "Player 3 Name is required." }),
  player4Name: z.string().min(2, { message: "Player 4 Name is required." }),
  player5Name: z.string().min(2, { message: "Player 5 Name is required." }),
  player6Name: z.string().optional(),
});

type BookingFormValues = z.infer<typeof bookingFormSchema>;

interface BookingFormProps {
  tournament: Tournament;
}

export function BookingForm({ tournament }: BookingFormProps) {
  const router = useRouter();
  const { toast } = useToast();

  const form = useForm<BookingFormValues>({
    resolver: zodResolver(bookingFormSchema),
    defaultValues: {
      playerName: "",
      ign: "",
      email: "",
      teamName: "",
      player2Name: "",
      player3Name: "",
      player4Name: "",
      player5Name: "",
      player6Name: "",
    },
  });

  const [isBooked, setIsBooked] = useState(false);

  function onSubmit(data: BookingFormValues) {
    console.log("Booking data:", data);

    if (tournament.entryFee === 0) {
      // Direct slot reservation for free tournaments
      handleSuccessfulBookingAction(tournament.id)
        .then(result => {
          if (result.success) {
            toast({
              title: "Slot Reserved!",
              description: `Your slot for ${tournament.name} is confirmed.`,
            });
            setIsBooked(true); // Show social media links
          } else {
            toast({
              title: "Reservation Failed",
              description: result.error || "Could not reserve slot. Please try again.",
              variant: "destructive",
            });
          }
        })
        .catch(error => {
          console.error("Error reserving free slot:", error);
          toast({
            title: "An Error Occurred",
            description: "Could not reserve slot due to an unexpected error. Please contact support.",
            variant: "destructive",
          });
        });
    } else {
      // For paid tournaments, proceed to payment
      toast({
        title: "Details Submitted!",
        description: "Proceed to payment to confirm your slot.",
      });
      router.push(`/tournaments/${tournament.id}/payment`);
    }
  }

  if (isBooked) {
    return (
      <div className="text-center space-y-6">
        <h3 className="font-headline text-2xl text-neon-primary">Thank You for Booking!</h3>
        <p className="text-muted-foreground">Your slot has been successfully reserved.</p>
        <p className="text-muted-foreground">Stay updated with the latest news, tournaments, and community events by following us on social media:</p>
        <div className="flex flex-wrap justify-center gap-4 md:gap-6">
          <Button variant="outline" size="lg" asChild className="border-primary/50 hover:bg-primary/10 hover:border-primary text-foreground">
            <Link href="https://discord.gg/xPGJCWpMbM" target="_blank" rel="noopener noreferrer">
              <MessageSquare className="mr-2 h-5 w-5 icon-glow-primary" /> Discord
            </Link>
          </Button>
          <Button variant="outline" size="lg" asChild className="border-primary/50 hover:bg-primary/10 hover:border-primary text-foreground">
            <Link href="https://www.instagram.com/nexus_esports.ig/" target="_blank" rel="noopener noreferrer">
              <Instagram className="mr-2 h-5 w-5 icon-glow-primary" /> Instagram
            </Link>
          </Button>
          <Button variant="outline" size="lg" asChild className="border-primary/50 hover:bg-primary/10 hover:border-primary text-foreground">
            <Link href="https://www.youtube.com/@nexus_esports_official" target="_blank" rel="noopener noreferrer">
              <Youtube className="mr-2 h-5 w-5 icon-glow-primary" /> YouTube
            </Link>
          </Button>
        </div>
        <Button onClick={() => router.push('/tournaments')} className="mt-8 font-headline text-lg py-6" size="lg">
          Back to Tournaments
        </Button>
      </div>
    );
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <FormField
          control={form.control}
          name="playerName"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="flex items-center gap-2"><User className="w-4 h-4 text-primary" />Player 1 Name</FormLabel>
              <FormControl>
                <Input placeholder="Enter player 1's full name" {...field} />
              </FormControl>
              <FormDescription>This name will be used for registration.</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="ign"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="flex items-center gap-2"><Gamepad className="w-4 h-4 text-primary" />In-Game Name (IGN)</FormLabel>
              <FormControl>
                <Input placeholder="Your Free Fire IGN" {...field} />
              </FormControl>
              <FormDescription>Your unique name in Free Fire.</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="flex items-center gap-2"><Mail className="w-4 h-4 text-primary" />Email Address</FormLabel>
              <FormControl>
                <Input type="email" placeholder="your.email@example.com" {...field} />
              </FormControl>
              <FormDescription>We'll send booking confirmation here.</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="teamName"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="flex items-center gap-2"><Users className="w-4 h-4 text-primary" />Team Name</FormLabel>
              <FormControl>
                <Input placeholder="Your team's name" {...field} />
              </FormControl>
              <FormDescription>If registering as part of a team.</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="player2Name"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="flex items-center gap-2"><User className="w-4 h-4 text-primary" />Player 2 Name</FormLabel>
              <FormControl>
                <Input placeholder="Enter player 2's full name" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="player3Name"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="flex items-center gap-2"><User className="w-4 h-4 text-primary" />Player 3 Name</FormLabel>
              <FormControl>
                <Input placeholder="Enter player 3's full name" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="player4Name"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="flex items-center gap-2"><User className="w-4 h-4 text-primary" />Player 4 Name</FormLabel>
              <FormControl>
                <Input placeholder="Enter player 4's full name" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="player5Name"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="flex items-center gap-2"><User className="w-4 h-4 text-primary" />Player 5 Name</FormLabel>
              <FormControl>
                <Input placeholder="Enter player 5's full name" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="player6Name"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="flex items-center gap-2"><User className="w-4 h-4 text-primary" />Player 6 Name (Optional)</FormLabel>
              <FormControl>
                <Input placeholder="Enter player 6's full name" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button type="submit" className="w-full font-headline text-lg py-6" size="lg">
          Book Your Slot
        </Button>
      </form>
    </Form>
  );
}
