"use client";

import { useState, useEffect } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import type { Tournament } from '@/lib/types';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';
import { CheckCircle, AlertTriangle, QrCode, Copy } from 'lucide-react';
import { handleSuccessfulBookingAction } from '@/lib/actions'; // Import the server action

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";

const paymentFormSchema = z.object({
  transactionId: z.string().min(10, { message: "Please enter a valid Transaction ID (e.g., UPI Transaction ID)." }),
});

type PaymentFormValues = z.infer<typeof paymentFormSchema>;

interface PaymentFlowProps {
  tournament: Tournament;
}

export function PaymentFlow({ tournament }: PaymentFlowProps) {
  const router = useRouter();
  const { toast } = useToast();
  const [paymentStatus, setPaymentStatus] = useState<'pending' | 'processing' | 'success' | 'failed'>('pending');
  const upiId = "nexusslots@upi"; // Example UPI ID

  const form = useForm<PaymentFormValues>({
    resolver: zodResolver(paymentFormSchema),
    defaultValues: {
      transactionId: "",
    },
  });

  const handleConfirmPayment = async (values: PaymentFormValues) => {
    setPaymentStatus('processing');
    // In a real app, you would send values.transactionId to your backend for verification
    console.log("User entered Transaction ID:", values.transactionId);

    // Simulate payment processing
    setTimeout(async () => {
      const isSuccess = Math.random() > 0.1; // 90% success rate
      if (isSuccess) {
        try {
          const result = await handleSuccessfulBookingAction(tournament.id, values.transactionId); // Pass transactionId
          if (result.success) {
            setPaymentStatus('success');
            toast({
              title: "Payment Successful!",
              description: `Your slot for ${tournament.name} is confirmed. Slots remaining: ${result.newSlotCount}`,
              variant: "default",
            });
            router.refresh(); // Refresh the current route to get updated data
            // Redirect to confirmation page after a short delay
            setTimeout(() => {
              router.push(`/tournaments/${tournament.id}/confirmation`);
            }, 2000);
          } else {
            throw new Error(result.error || "Server action failed to update slot count.");
          }
        } catch (error) {
          console.error("Error during booking action or UI update:", error);
          setPaymentStatus('failed');
          toast({
            title: "Booking Partially Failed",
            description: "Payment might be okay, but updating slot count failed. Please contact support.",
            variant: "destructive",
          });
        }
      } else {
        setPaymentStatus('failed');
        toast({
          title: "Payment Failed",
          description: "Please try again or contact support.",
          variant: "destructive",
        });
      }
    }, 3000); // Simulate 3 seconds processing time
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(upiId).then(() => {
      toast({ title: "UPI ID Copied!", description: upiId });
    }).catch(err => {
      toast({ title: "Failed to copy", variant: "destructive" });
      console.error('Failed to copy: ', err);
    });
  };


  if (paymentStatus === 'processing') {
    return (
      <div className="text-center space-y-4 py-8">
        <LoadingSpinner size={48} />
        <p className="font-headline text-xl text-neon-accent animate-pulse-fast">Processing Payment...</p>
        <p className="text-muted-foreground">Please wait, do not refresh the page.</p>
      </div>
    );
  }

  if (paymentStatus === 'success') {
    return (
      <div className="text-center space-y-4 py-8">
        <CheckCircle className="w-16 h-16 text-green-500 mx-auto animate-pulse-fast" />
        <p className="font-headline text-2xl text-green-500">Payment Successful!</p>
        <p className="text-muted-foreground">Redirecting to confirmation page...</p>
      </div>
    );
  }
  
  if (paymentStatus === 'failed') {
    return (
      <div className="text-center space-y-4 py-8">
        <AlertTriangle className="w-16 h-16 text-destructive mx-auto" />
        <p className="font-headline text-2xl text-destructive">Payment Failed</p>
        <p className="text-muted-foreground">Something went wrong with your payment.</p>
        <Button onClick={() => setPaymentStatus('pending')} className="mt-4">Try Again</Button>
      </div>
    );
  }

  return (
    <Card className="w-full max-w-md mx-auto shadow-xl">
      <CardHeader>
        <CardTitle className="font-headline text-2xl flex items-center gap-2">
           <QrCode className="w-6 h-6 text-primary"/> UPI Payment
        </CardTitle>
        <CardDescription>
          Scan the QR code or use the UPI ID to pay ₹{tournament.entryFee} for {tournament.name}.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex justify-center p-4 bg-muted rounded-lg">
          <Image
            src={`https://placehold.co/250x250.png?text=Scan+QR`} // Placeholder for QR code
            alt="UPI QR Code"
            width={250}
            height={250}
            className="rounded-md border"
            data-ai-hint="QR code payment"
          />
        </div>
        <div className="text-center space-y-2">
          <p className="text-sm text-muted-foreground">Or pay to UPI ID:</p>
          <div className="flex items-center justify-center gap-2 p-3 bg-muted rounded-md">
            <p className="font-mono text-lg text-accent">{upiId}</p>
            <Button variant="ghost" size="icon" onClick={copyToClipboard} aria-label="Copy UPI ID">
              <Copy className="w-4 h-4" />
            </Button>
          </div>
        </div>
        <p className="text-sm text-center text-muted-foreground font-semibold">
            After completing the payment, please enter the Transaction ID below and click "Confirm Payment".
            Ensure payment is successful before confirming.
        </p>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleConfirmPayment)} className="space-y-4">
            <FormField
              control={form.control}
              name="transactionId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>UPI Transaction ID</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter your UPI Transaction ID (e.g., UTR, Ref ID)" {...field} />
                  </FormControl>
                  <FormDescription>This helps us verify your payment.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button 
                type="submit" 
                className="w-full font-headline text-lg py-6" 
                size="lg"
                disabled={paymentStatus !== 'pending'}
            >
              Confirm Payment
            </Button>
          </form>
        </Form>
      </CardContent>
      <CardFooter>
        {/* Buttons are now inside the form */}
      </CardFooter>
    </Card>
  );
}
