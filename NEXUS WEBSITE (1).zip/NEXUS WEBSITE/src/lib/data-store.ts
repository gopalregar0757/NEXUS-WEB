import fs from 'fs';
import path from 'path';

// Define types
export interface User {
  id: string;
  username: string;
  email: string;
  password: string; // In a real app, this would be hashed
  role: 'player' | 'admin';
  status: 'active' | 'inactive';
  joinedDate: string;
  teamName?: string;
}

export interface Tournament {
  id: string;
  name: string;
  description: string;
  startDate: string;
  endDate: string;
  entryFee: number;
  totalSlots: number;
  availableSlots: number;
  status: 'upcoming' | 'ongoing' | 'completed';
  imageUrl: string;
}

export interface Booking {
  id: string;
  tournamentId: string;
  userId: string;
  teamName: string;
  playerNames: string[];
  status: 'confirmed' | 'pending' | 'cancelled';
  bookingDate: string;
  paymentStatus: 'paid' | 'pending' | 'free';
  transactionId?: string;
}

export interface Payment {
  id: string;
  bookingId: string;
  tournamentId: string;
  userId: string;
  amount: number;
  status: 'completed' | 'pending' | 'failed';
  date: string;
  transactionId: string;
}

// Data store paths
const DATA_DIR = path.join(process.cwd(), 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const TOURNAMENTS_FILE = path.join(DATA_DIR, 'tournaments.json');
const BOOKINGS_FILE = path.join(DATA_DIR, 'bookings.json');
const PAYMENTS_FILE = path.join(DATA_DIR, 'payments.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initialize data files if they don't exist
const initializeFile = (filePath: string, initialData: any[]) => {
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify(initialData, null, 2));
  }
};

// Initialize all data files
initializeFile(USERS_FILE, [
  {
    id: 'USER001',
    username: 'admin',
    email: 'admin@nexusesports.com',
    password: 'admin123', // In a real app, this would be hashed
    role: 'admin',
    status: 'active',
    joinedDate: new Date('2024-01-01').toISOString(),
  }
]);

initializeFile(TOURNAMENTS_FILE, [
  {
    id: 'T001',
    name: 'Nexus FF Clash Series Season 1',
    description: 'Join the biggest Free Fire tournament series!',
    startDate: new Date('2024-04-01').toISOString(),
    endDate: new Date('2024-04-07').toISOString(),
    entryFee: 499,
    totalSlots: 100,
    availableSlots: 85,
    status: 'upcoming',
    imageUrl: '/tournaments/nexus-ff-clash.jpg',
  },
  {
    id: 'T002',
    name: 'Sunday Clash',
    description: 'Weekly tournament for all skill levels',
    startDate: new Date('2024-03-17').toISOString(),
    endDate: new Date('2024-03-17').toISOString(),
    entryFee: 0,
    totalSlots: 50,
    availableSlots: 35,
    status: 'upcoming',
    imageUrl: '/tournaments/sunday-clash.jpg',
  }
]);

initializeFile(BOOKINGS_FILE, []);
initializeFile(PAYMENTS_FILE, []);

// Helper functions to read and write data
const readData = <T>(filePath: string): T[] => {
  try {
    const data = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    console.error(`Error reading ${filePath}:`, error);
    return [];
  }
};

const writeData = <T>(filePath: string, data: T[]): void => {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error(`Error writing to ${filePath}:`, error);
  }
};

// Data access functions
export const dataStore = {
  // Users
  getUsers: () => readData<User>(USERS_FILE),
  getUserById: (id: string) => readData<User>(USERS_FILE).find(user => user.id === id),
  getUserByEmail: (email: string) => readData<User>(USERS_FILE).find(user => user.email === email),
  createUser: (user: Omit<User, 'id' | 'joinedDate'>) => {
    const users = readData<User>(USERS_FILE);
    const newUser: User = {
      ...user,
      id: `USER${String(users.length + 1).padStart(3, '0')}`,
      joinedDate: new Date().toISOString(),
    };
    writeData(USERS_FILE, [...users, newUser]);
    return newUser;
  },

  // Tournaments
  getTournaments: () => readData<Tournament>(TOURNAMENTS_FILE),
  getTournamentById: (id: string) => readData<Tournament>(TOURNAMENTS_FILE).find(t => t.id === id),
  updateTournamentSlots: (id: string, decrement: boolean) => {
    const tournaments = readData<Tournament>(TOURNAMENTS_FILE);
    const tournament = tournaments.find(t => t.id === id);
    if (tournament) {
      tournament.availableSlots += decrement ? -1 : 1;
      writeData(TOURNAMENTS_FILE, tournaments);
    }
    return tournament;
  },

  // Bookings
  getBookings: () => readData<Booking>(BOOKINGS_FILE),
  getBookingsByUserId: (userId: string) => readData<Booking>(BOOKINGS_FILE).filter(b => b.userId === userId),
  createBooking: (booking: Omit<Booking, 'id' | 'bookingDate'>) => {
    const bookings = readData<Booking>(BOOKINGS_FILE);
    const newBooking: Booking = {
      ...booking,
      id: `B${String(bookings.length + 1).padStart(3, '0')}`,
      bookingDate: new Date().toISOString(),
    };
    writeData(BOOKINGS_FILE, [...bookings, newBooking]);
    return newBooking;
  },

  // Payments
  getPayments: () => readData<Payment>(PAYMENTS_FILE),
  getPaymentsByUserId: (userId: string) => readData<Payment>(PAYMENTS_FILE).filter(p => p.userId === userId),
  createPayment: (payment: Omit<Payment, 'id' | 'date'>) => {
    const payments = readData<Payment>(PAYMENTS_FILE);
    const newPayment: Payment = {
      ...payment,
      id: `PAY${String(payments.length + 1).padStart(3, '0')}`,
      date: new Date().toISOString(),
    };
    writeData(PAYMENTS_FILE, [...payments, newPayment]);
    return newPayment;
  },
}; 