"use client";

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { formatDate } from '@/lib/utils';
import Link from 'next/link';

// Mock booked slots data
const mockBookedSlots = [
  {
    id: 'SLOT001',
    tournamentName: 'Nexus FF Clash Series Season 1',
    teamName: 'Team Alpha',
    status: 'confirmed',
    entryFee: 499,
    startDate: new Date('2024-04-01T10:00:00'),
    endDate: new Date('2024-04-07T18:00:00'),
    paymentStatus: 'paid',
  },
  {
    id: 'SLOT002',
    tournamentName: 'Weekend Warriors',
    teamName: 'Team Beta',
    status: 'confirmed',
    entryFee: 299,
    startDate: new Date('2024-03-23T15:00:00'),
    endDate: new Date('2024-03-24T18:00:00'),
    paymentStatus: 'paid',
  },
  {
    id: 'SLOT003',
    tournamentName: 'Sunday Clash',
    teamName: 'Team Gamma',
    status: 'confirmed',
    entryFee: 0,
    startDate: new Date('2024-03-17T11:00:00'),
    endDate: new Date('2024-03-17T18:00:00'),
    paymentStatus: 'free',
  },
];

export default function YourSlotsPage() {
  const [bookedSlots] = useState(mockBookedSlots);

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="text-center">
          <h1 className="font-headline text-3xl md:text-4xl text-neon-primary">Your Booked Slots</h1>
          <p className="text-lg text-gray-300 mt-2">
            View and manage tournaments you've registered for
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Active Registrations</CardTitle>
            <CardDescription>Your confirmed tournament slots</CardDescription>
          </CardHeader>
          <CardContent>
            {bookedSlots.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Tournament</TableHead>
                    <TableHead>Team</TableHead>
                    <TableHead>Dates</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Entry</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {bookedSlots.map((slot) => (
                    <TableRow key={slot.id}>
                      <TableCell className="font-medium">{slot.tournamentName}</TableCell>
                      <TableCell>{slot.teamName}</TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div>Start: {formatDate(slot.startDate)}</div>
                          <div>End: {formatDate(slot.endDate)}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={slot.status === 'confirmed' ? 'default' : 'secondary'}>
                          {slot.status.charAt(0).toUpperCase() + slot.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {slot.entryFee === 0 ? (
                          <Badge variant="outline" className="text-green-500">Free Entry</Badge>
                        ) : (
                          <Badge variant={slot.paymentStatus === 'paid' ? 'default' : 'secondary'}>
                            ₹{slot.entryFee}
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <Button variant="outline" size="sm" asChild>
                          <Link href={`/tournaments/${slot.id}`}>View Details</Link>
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground">You haven't booked any tournament slots yet</p>
                <Button asChild className="mt-4">
                  <Link href="/tournaments">Browse Tournaments</Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
