import { TournamentCard } from '@/components/tournament/TournamentCard';
import { mockTournaments } from '@/lib/data';
import type { Tournament } from '@/lib/types';

export const dynamic = 'force-dynamic'; // Ensures the page is always dynamically rendered

export default function TournamentsPage() {
  const tournaments: Tournament[] = mockTournaments; // In a real app, fetch this data

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <section id="all-tournaments" className="mb-12">
        <h1 className="font-headline text-4xl md:text-5xl font-bold mb-8 text-center text-neon-primary">
          All Tournaments
        </h1>
        {tournaments.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {tournaments.map((tournament) => (
              <TournamentCard key={tournament.id} tournament={tournament} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-xl text-muted-foreground">No tournaments available at the moment. Check back soon!</p>
          </div>
        )}
      </section>

      <section id="coming-soon" className="mt-16">
        <div className="bg-card/50 rounded-lg p-8 text-center border border-dashed">
          <h3 className="font-headline text-2xl mb-4 text-primary">More Tournaments Coming Soon!</h3>
          <p className="text-muted-foreground text-lg mb-6">
            We are working on bringing you more exciting tournaments with amazing prizes.
            Stay tuned for updates!
          </p>
          <div className="flex justify-center gap-4 text-sm text-muted-foreground">
            <span>• New Tournament Formats</span>
            <span>• Special Events</span>
            <span>• Bigger Prize Pools</span>
          </div>
        </div>
      </section>
    </div>
  );
}
