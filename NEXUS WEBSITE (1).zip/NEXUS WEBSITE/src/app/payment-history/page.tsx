"use client";

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { formatDate } from '@/lib/utils';

// Mock payment history data
const mockPayments = [
  {
    id: 'PAY001',
    tournamentName: 'Nexus FF Clash Series Season 1',
    amount: 499,
    status: 'completed',
    date: new Date('2024-03-15T10:30:00'),
    transactionId: 'UPI123456789',
  },
  {
    id: 'PAY002',
    tournamentName: 'Weekend Warriors',
    amount: 299,
    status: 'completed',
    date: new Date('2024-03-10T15:45:00'),
    transactionId: 'UPI987654321',
  },
  {
    id: 'PAY003',
    tournamentName: 'Sunday Clash',
    amount: 0,
    status: 'completed',
    date: new Date('2024-03-05T09:15:00'),
    transactionId: 'FREE-ENTRY',
  },
];

export default function PaymentHistoryPage() {
  const [payments] = useState(mockPayments);

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="text-center">
          <h1 className="font-headline text-3xl md:text-4xl text-neon-primary">Payment History</h1>
          <p className="text-lg text-gray-300 mt-2">
            Review your past transaction records for tournament entries
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Transaction History</CardTitle>
            <CardDescription>Your recent tournament entry payments</CardDescription>
          </CardHeader>
          <CardContent>
            {payments.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Tournament</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Transaction ID</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {payments.map((payment) => (
                    <TableRow key={payment.id}>
                      <TableCell>{formatDate(payment.date)}</TableCell>
                      <TableCell>{payment.tournamentName}</TableCell>
                      <TableCell>
                        {payment.amount === 0 ? (
                          <span className="text-green-500">Free Entry</span>
                        ) : (
                          `₹${payment.amount}`
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant={payment.status === 'completed' ? 'default' : 'secondary'}>
                          {payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-mono text-sm">
                        {payment.transactionId}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No payment history found</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
