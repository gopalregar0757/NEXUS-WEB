import { Button } from '@/components/ui/button';
import { MessageSquare } from 'lucide-react';
import Link from 'next/link';

export default function ScrimsPage() {
  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <div className="max-w-3xl mx-auto text-center space-y-6">
        <h1 className="font-headline text-3xl md:text-4xl text-neon-primary">Scrims</h1>
        <p className="text-lg text-gray-300 mt-2">
          Join our practice matches and improve your gameplay.
        </p>

        <div className="p-6 bg-gray-800 rounded-lg border border-gray-700">
          <h2 className="font-headline text-xl text-accent mb-4">Feature Under Development</h2>
          <p className="text-gray-200 mb-4 leading-relaxed">
            We are currently developing an advanced scrim management system to enhance your practice experience.
            This system will include automated scheduling, team management, and real-time match updates.
          </p>
          <div className="mt-6 p-4 bg-gray-900 rounded-lg border border-gray-700">
            <h3 className="font-medium text-primary mb-2">Join Our WhatsApp Community</h3>
            <p className="text-gray-300 mb-4">
              In the meantime, we invite you to join our dedicated WhatsApp group for scrim coordination.
              Connect with fellow players, schedule practice matches, and stay updated with our latest scrim announcements.
            </p>
            <Button asChild className="w-full sm:w-auto">
              <Link
                href="https://chat.whatsapp.com/your-group-invite-link"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2"
              >
                <MessageSquare className="h-5 w-5" />
                Join Scrims WhatsApp Group
              </Link>
            </Button>
          </div>
        </div>

        <div className="text-center text-sm text-gray-400">
          <p>Our automated scrim system will be available soon!</p>
          <p className="mt-1">Stay tuned for updates and enhanced features.</p>
        </div>
      </div>
    </div>
  );
}
