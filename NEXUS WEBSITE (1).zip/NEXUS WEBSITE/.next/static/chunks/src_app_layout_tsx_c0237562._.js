(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__2ff67a28._.css",
  "static/chunks/src_9bb14070._.js",
  "static/chunks/node_modules_df9af78a._.js"
],
    source: "dynamic"
});
