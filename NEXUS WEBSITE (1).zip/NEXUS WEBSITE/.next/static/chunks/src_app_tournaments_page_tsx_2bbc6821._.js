(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_d0f7b7b4._.js",
  "static/chunks/src_components_5555470c._.js"
],
    source: "dynamic"
});
