(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_54af5e44._.js",
  "static/chunks/src_f31afe55._.js"
],
    source: "dynamic"
});
