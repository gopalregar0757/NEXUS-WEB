(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_beaad824._.js",
  "static/chunks/src_components_9c60c84e._.js"
],
    source: "dynamic"
});
