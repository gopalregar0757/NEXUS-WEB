(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_aac4916b._.js",
  "static/chunks/src_77d5d393._.js"
],
    source: "dynamic"
});
